#!/bin/bash

SUPPORT_MIX=../Application/SupportMix
if [ -f supportMixTestConfiguration.cfg ] 
then
  ${SUPPORT_MIX}  -c22 -C supportMixTestConfiguration.cfg

else
  echo Test configuration not found, creating configuration...
  x=$(pwd)
  sed "s#BASEPATH#$x#g" templates/supportMixTestConfiguration.template > supportMixTestConfiguration.cfg
  if [ -f supportMixTestConfiguration.cfg ]
  then
     echo Configuration created.
     echo Starting SupportMix...
     ${SUPPORT_MIX}  -c22 -C supportMixTestConfiguration.cfg
  else
     echo Error while creating configuration.
  fi

fi

