# Local Ancestry Tutorial

You can follow the [notebook](https://github.com/bcm-uga/Loter/blob/master/python-package/Local%20Ancestry%20Example.ipynb).

# Simulations of admixed individuals

Informations about are available on [GitHub](https://github.com/BioShock38/aede).
