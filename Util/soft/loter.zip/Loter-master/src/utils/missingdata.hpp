#ifndef MISSINGDATA_HPP
#define MISSINGDATA_HPP

extern const int NaN;

#endif
