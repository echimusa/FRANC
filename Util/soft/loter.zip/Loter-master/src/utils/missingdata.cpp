#include "missingdata.hpp"

const int NaN = 3;
